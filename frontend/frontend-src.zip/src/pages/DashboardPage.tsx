import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

interface EmissionLog {
  id: number;
  totalEmissionsKg: number;
  createdAt: string;
}

const DashboardPage = () => {
  const [logs, setLogs] = useState<EmissionLog[]>([]);
  const [userEmail, setUserEmail] = useState('');
  const [authChecked, setAuthChecked] = useState(false);
  const [authorized, setAuthorized] = useState(false);
  const [aiResponse, setAiResponse] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const checkUser = async () => {
      try {
        const res = await fetch('http://localhost:8080/api/users/me', {
          credentials: 'include',
        });
        if (!res.ok) throw new Error('Unauthorized');

        const user = await res.json();
        if (!user.enabled) throw new Error('User not approved');
        setUserEmail(user.email);
        setAuthorized(true);
      } catch {
        navigate('/login');
      } finally {
        setAuthChecked(true);
      }
    };

    checkUser();
  }, []);

  useEffect(() => {
    if (authorized) {
      fetch('http://localhost:8080/api/logs', {
        credentials: 'include',
      })
        .then((res) => res.json())
        .then((data) => setLogs(data))
        .catch((err) => console.error('Error fetching logs:', err));
    }
  }, [authorized]);

  const handleAISuggestions = async (logId: number) => {
    const res = await fetch(`http://localhost:8080/api/ai/suggestions/${logId}`, {
      credentials: 'include',
    });
    const text = await res.text();
    setAiResponse(text);
  };

  if (!authChecked) return null;

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Welcome, {userEmail}</h1>

      <h2 className="text-xl font-semibold mb-2">Your Emission Logs</h2>
      {logs.length === 0 ? (
        <p>No logs found.</p>
      ) : (
        <table className="w-full bg-white shadow-md rounded mb-6">
          <thead>
            <tr className="bg-gray-200 text-left">
              <th className="p-2">Date</th>
              <th className="p-2">Total Emissions (kg)</th>
              <th className="p-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {logs.map((log) => (
              <tr key={log.id} className="border-t">
                <td className="p-2">{new Date(log.createdAt).toLocaleDateString()}</td>
                <td className="p-2">{log.totalEmissionsKg.toFixed(2)}</td>
                <td className="p-2">
                  <button
                    className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded"
                    onClick={() => handleAISuggestions(log.id)}
                  >
                    AI Suggestions
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {aiResponse && (
        <div className="bg-green-50 p-4 border border-green-200 rounded">
          <h3 className="font-semibold text-green-700 mb-2">AI Suggestions:</h3>
          <pre className="whitespace-pre-wrap">{aiResponse}</pre>
        </div>
      )}
    </div>
  );
};

export default DashboardPage;
