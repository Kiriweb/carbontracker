package com.carbontracker.dto;

public class ElectricityUseDTO {
    private Long emissionLogId;
    private String countryCode;
    private Double consumptionKwh;

    // Getters & Setters
    public Long getEmissionLogId() { return emissionLogId; }
    public void setEmissionLogId(Long emissionLogId) { this.emissionLogId = emissionLogId; }

    public String getCountryCode() { return countryCode; }
    public void setCountryCode(String countryCode) { this.countryCode = countryCode; }

    public Double getConsumptionKwh() { return consumptionKwh; }
    public void setConsumptionKwh(Double consumptionKwh) { this.consumptionKwh = consumptionKwh; }
}