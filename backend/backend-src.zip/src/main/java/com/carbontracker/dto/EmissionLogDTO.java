package com.carbontracker.dto;

import java.time.LocalDate;

public class EmissionLogDTO {
    private LocalDate date;
    private Double totalEmissionsKg;

    // Getters & Setters
    public LocalDate getDate() { return date; }
    public void setDate(LocalDate date) { this.date = date; }

    public Double getTotalEmissionsKg() { return totalEmissionsKg; }
    public void setTotalEmissionsKg(Double totalEmissionsKg) { this.totalEmissionsKg = totalEmissionsKg; }
}

