package com.carbontracker.dto;

public class WasteDisposalDTO {
    private Long emissionLogId;
    private String wasteType;
    private String method;
    private Double weightKg;

    // Getters & Setters
    public Long getEmissionLogId() { return emissionLogId; }
    public void setEmissionLogId(Long emissionLogId) { this.emissionLogId = emissionLogId; }

    public String getWasteType() { return wasteType; }
    public void setWasteType(String wasteType) { this.wasteType = wasteType; }

    public String getMethod() { return method; }
    public void setMethod(String method) { this.method = method; }

    public Double getWeightKg() { return weightKg; }
    public void setWeightKg(Double weightKg) { this.weightKg = weightKg; }
}

