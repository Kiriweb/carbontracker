package com.carbontracker.dto;

public class VehicleTripDTO {
    private Long emissionLogId;
    private String vehicleType;
    private String fuelType;
    private Double distanceKm;
    private Double emissionsKg;

    // Getters & Setters
    public Long getEmissionLogId() { return emissionLogId; }
    public void setEmissionLogId(Long emissionLogId) { this.emissionLogId = emissionLogId; }

    public String getVehicleType() { return vehicleType; }
    public void setVehicleType(String vehicleType) { this.vehicleType = vehicleType; }

    public String getFuelType() { return fuelType; }
    public void setFuelType(String fuelType) { this.fuelType = fuelType; }

    public Double getDistanceKm() { return distanceKm; }
    public void setDistanceKm(Double distanceKm) { this.distanceKm = distanceKm; }

    public Double getEmissionsKg() { return emissionsKg; }
    public void setEmissionsKg(Double emissionsKg) { this.emissionsKg = emissionsKg; }
}