package com.carbontracker.dto;

public class FuelCombustionDTO {
    private Long emissionLogId;
    private String fuelType;
    private String unit;
    private Double quantity;

    // Getters & Setters
    public Long getEmissionLogId() { return emissionLogId; }
    public void setEmissionLogId(Long emissionLogId) { this.emissionLogId = emissionLogId; }

    public String getFuelType() { return fuelType; }
    public void setFuelType(String fuelType) { this.fuelType = fuelType; }

    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }

    public Double getQuantity() { return quantity; }
    public void setQuantity(Double quantity) { this.quantity = quantity; }
}