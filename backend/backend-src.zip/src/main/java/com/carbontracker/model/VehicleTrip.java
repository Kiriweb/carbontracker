package com.carbontracker.model;

import jakarta.persistence.*;

@Entity
@Table(name = "vehicle_trips")
public class VehicleTrip {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "emission_log_id", nullable = false)
    private EmissionLog emissionLog;

    private String vehicleType;   // e.g., "supermini"
    private String fuelType;      // e.g., "petrol", "diesel"
    private Double distanceKm;
    private Double emissionsKg;

    // Getters & Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public EmissionLog getEmissionLog() { return emissionLog; }
    public void setEmissionLog(EmissionLog emissionLog) { this.emissionLog = emissionLog; }

    public String getVehicleType() { return vehicleType; }
    public void setVehicleType(String vehicleType) { this.vehicleType = vehicleType; }

    public String getFuelType() { return fuelType; }
    public void setFuelType(String fuelType) { this.fuelType = fuelType; }

    public Double getDistanceKm() { return distanceKm; }
    public void setDistanceKm(Double distanceKm) { this.distanceKm = distanceKm; }

    public Double getEmissionsKg() { return emissionsKg; }
    public void setEmissionsKg(Double emissionsKg) { this.emissionsKg = emissionsKg; }
}

