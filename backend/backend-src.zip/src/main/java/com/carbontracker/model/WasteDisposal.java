package com.carbontracker.model;

import jakarta.persistence.*;

@Entity
@Table(name = "waste_disposal")
public class WasteDisposal {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "emission_log_id", nullable = false)
    private EmissionLog emissionLog;

    private String wasteType;
    private String method;
    private Double weightKg;
    private Double emissionsKg;

    // Getters & Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public EmissionLog getEmissionLog() { return emissionLog; }
    public void setEmissionLog(EmissionLog emissionLog) { this.emissionLog = emissionLog; }

    public String getWasteType() { return wasteType; }
    public void setWasteType(String wasteType) { this.wasteType = wasteType; }

    public String getMethod() { return method; }
    public void setMethod(String method) { this.method = method; }

    public Double getWeightKg() { return weightKg; }
    public void setWeightKg(Double weightKg) { this.weightKg = weightKg; }

    public Double getEmissionsKg() { return emissionsKg; }
    public void setEmissionsKg(Double emissionsKg) { this.emissionsKg = emissionsKg; }
}

