package com.carbontracker.model;

import jakarta.persistence.*;

@Entity
@Table(name = "electricity_use")
public class ElectricityUse {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "emission_log_id", nullable = false)
    private EmissionLog emissionLog;

    private String countryCode;
    private Double consumptionKwh;
    private Double emissionsKg;

    // Getters & Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public EmissionLog getEmissionLog() {
        return emissionLog;
    }

    public void setEmissionLog(EmissionLog emissionLog) {
        this.emissionLog = emissionLog;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public Double getConsumptionKwh() {
        return consumptionKwh;
    }

    public void setConsumptionKwh(Double consumptionKwh) {
        this.consumptionKwh = consumptionKwh;
    }

    public Double getEmissionsKg() {
        return emissionsKg;
    }

    public void setEmissionsKg(Double emissionsKg) {
        this.emissionsKg = emissionsKg;
    }
}

