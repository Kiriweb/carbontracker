package com.carbontracker.model;

import jakarta.persistence.*;

@Entity
@Table(name = "fuel_combustion")
public class FuelCombustion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "emission_log_id", nullable = false)
    private EmissionLog emissionLog;

    private String fuelType;
    private String unit;         // e.g., "kwh", "litre"
    private Double quantity;
    private Double emissionsKg;

    // Getters & Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public EmissionLog getEmissionLog() { return emissionLog; }
    public void setEmissionLog(EmissionLog emissionLog) { this.emissionLog = emissionLog; }

    public String getFuelType() { return fuelType; }
    public void setFuelType(String fuelType) { this.fuelType = fuelType; }

    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }

    public Double getQuantity() { return quantity; }
    public void setQuantity(Double quantity) { this.quantity = quantity; }

    public Double getEmissionsKg() { return emissionsKg; }
    public void setEmissionsKg(Double emissionsKg) { this.emissionsKg = emissionsKg; }
}

