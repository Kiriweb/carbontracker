package com.carbontracker.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "emission_logs")
public class EmissionLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(nullable = false)
    private LocalDate date;

    @Column(name = "total_emissions_kg")
    private Double totalEmissionsKg;

    // Getters & Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public LocalDate getDate() { return date; }
    public void setDate(LocalDate date) { this.date = date; }

    public Double getTotalEmissionsKg() { return totalEmissionsKg; }
    public void setTotalEmissionsKg(Double totalEmissionsKg) { this.totalEmissionsKg = totalEmissionsKg; }
}

