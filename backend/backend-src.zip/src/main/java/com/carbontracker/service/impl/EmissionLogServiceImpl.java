package com.carbontracker.service.impl;

import com.carbontracker.dto.EmissionLogDTO;
import com.carbontracker.model.EmissionLog;
import com.carbontracker.model.User;
import com.carbontracker.repository.EmissionLogRepository;
import com.carbontracker.repository.UserRepository;
import com.carbontracker.service.EmissionLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmissionLogServiceImpl implements EmissionLogService {

    private final EmissionLogRepository emissionLogRepository;
    private final UserRepository userRepository;

    @Autowired
    public EmissionLogServiceImpl(EmissionLogRepository emissionLogRepository, UserRepository userRepository) {
        this.emissionLogRepository = emissionLogRepository;
        this.userRepository = userRepository;
    }

    @Override
    public EmissionLog createEmissionLog(String userEmail, EmissionLogDTO dto) {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new RuntimeException("User not found"));

        EmissionLog log = new EmissionLog();
        log.setUser(user);
        log.setDate(dto.getDate());
        log.setTotalEmissionsKg(dto.getTotalEmissionsKg());

        return emissionLogRepository.save(log);
    }

    @Override
    public List<EmissionLog> getLogsByUser(String userEmail) {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new RuntimeException("User not found"));
        return emissionLogRepository.findByUserId(user.getId());
    }
}

