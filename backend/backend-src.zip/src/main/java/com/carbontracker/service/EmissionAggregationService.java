package com.carbontracker.service;

public interface EmissionAggregationService {
    void updateTotalEmissions(Long emissionLogId);
}

