package com.carbontracker.service.impl;

import com.carbontracker.model.*;
import com.carbontracker.repository.*;
import com.carbontracker.service.EmissionAggregationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmissionAggregationServiceImpl implements EmissionAggregationService {

    @Autowired private EmissionLogRepository emissionLogRepository;
    @Autowired private VehicleTripRepository vehicleTripRepository;
    @Autowired private ElectricityUseRepository electricityUseRepository;
    @Autowired private WasteDisposalRepository wasteDisposalRepository;
    @Autowired private FuelCombustionRepository fuelCombustionRepository;

    @Override
    public void updateTotalEmissions(Long emissionLogId) {
        EmissionLog log = emissionLogRepository.findById(emissionLogId)
                .orElseThrow(() -> new RuntimeException("Emission log not found"));

        double total = 0.0;

        List<VehicleTrip> trips = vehicleTripRepository.findByEmissionLogId(emissionLogId);
        for (VehicleTrip t : trips) total += t.getEmissionsKg();

        List<ElectricityUse> usages = electricityUseRepository.findByEmissionLogId(emissionLogId);
        for (ElectricityUse u : usages) total += u.getEmissionsKg();

        List<WasteDisposal> wastes = wasteDisposalRepository.findByEmissionLogId(emissionLogId);
        for (WasteDisposal w : wastes) total += w.getEmissionsKg();

        List<FuelCombustion> fuels = fuelCombustionRepository.findByEmissionLogId(emissionLogId);
        for (FuelCombustion f : fuels) total += f.getEmissionsKg();

        log.setTotalEmissionsKg(total);
        emissionLogRepository.save(log);
    }
}