package com.carbontracker.service;

import com.carbontracker.dto.EmissionLogDTO;
import com.carbontracker.model.EmissionLog;

import java.util.List;

public interface EmissionLogService {
    EmissionLog createEmissionLog(String userEmail, EmissionLogDTO dto);
    List<EmissionLog> getLogsByUser(String userEmail);
}

