package com.carbontracker.controller;

import com.carbontracker.dto.EmissionLogDTO;
import com.carbontracker.model.EmissionLog;
import com.carbontracker.service.EmissionLogService;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import com.carbontracker.util.JwtUtil;

@RestController
@RequestMapping("/api/logs")
public class EmissionLogController {

    private final EmissionLogService emissionLogService;
    private final JwtUtil jwtUtil;

    @Autowired
    public EmissionLogController(EmissionLogService emissionLogService, JwtUtil jwtUtil) {
        this.emissionLogService = emissionLogService;
        this.jwtUtil = jwtUtil;
    }

    private String extractEmailFromCookie(HttpServletRequest request) {
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("jwt")) {
                    return jwtUtil.validateToken(cookie.getValue());
                }
            }
        }
        return null;
    }

    @PostMapping
    public EmissionLog createLog(@RequestBody EmissionLogDTO dto, HttpServletRequest request) {
        String email = extractEmailFromCookie(request);
        return emissionLogService.createEmissionLog(email, dto);
    }

    @GetMapping
    public List<EmissionLog> getUserLogs(HttpServletRequest request) {
        String email = extractEmailFromCookie(request);
        return emissionLogService.getLogsByUser(email);
    }
}

