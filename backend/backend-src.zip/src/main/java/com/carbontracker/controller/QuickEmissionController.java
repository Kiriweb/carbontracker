package com.carbontracker.controller;

import com.carbontracker.dto.QuickEmissionRequest;
import com.carbontracker.model.EmissionLog;
import com.carbontracker.model.User;
import com.carbontracker.repository.EmissionLogRepository;
import com.carbontracker.repository.UserRepository;
import com.carbontracker.util.EmissionCalculator;
import com.carbontracker.util.JwtUtil;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Arrays;

@RestController
@RequestMapping("/api/emission-logs")
public class QuickEmissionController {

    private final EmissionCalculator calculator;
    private final EmissionLogRepository emissionLogRepository;
    private final UserRepository userRepository;
    private final JwtUtil jwtUtil;

    public QuickEmissionController(EmissionCalculator calculator,
                                   EmissionLogRepository emissionLogRepository,
                                   UserRepository userRepository,
                                   JwtUtil jwtUtil) {
        this.calculator = calculator;
        this.emissionLogRepository = emissionLogRepository;
        this.userRepository = userRepository;
        this.jwtUtil = jwtUtil;
    }

    @PostMapping("/quick")
    public ResponseEntity<?> createQuick(@RequestBody QuickEmissionRequest req,
                                         HttpServletRequest request) {

        User user = requireUserFromJwtCookie(request);
        if (user == null) {
            return ResponseEntity.status(401).body("Unauthenticated");
        }

        double co2e;
        String details;

        switch (req.category().toLowerCase()) {
            case "vehicle trip" -> {
                // vehicleType like "car", fuelType like "diesel"
                co2e = calculator.calculateVehicleEmissions(
                        req.vehicleType(), req.vehicleFuel(), req.distanceKm() != null ? req.distanceKm() : 0.0);
                details = String.format("Vehicle %s (%s), distance=%.3f km",
                        n(req.vehicleType()), n(req.vehicleFuel()), nz(req.distanceKm()));
            }
            case "electricity use" -> {
                co2e = calculator.calculateElectricityEmissions(
                        req.electricityCountry(), req.kwh() != null ? req.kwh() : 0.0);
                details = String.format("Electricity, country=%s, kWh=%.3f",
                        n(req.electricityCountry()), nz(req.kwh()));
            }
            case "waste disposal" -> {
                co2e = calculator.calculateWasteEmissions(
                        req.wasteType(), req.wasteMethod(), req.wasteKg() != null ? req.wasteKg() : 0.0);
                details = String.format("Waste %s via %s, weight=%.3f kg",
                        n(req.wasteType()), n(req.wasteMethod()), nz(req.wasteKg()));
            }
            case "fuel combustion" -> {
                co2e = calculator.calculateFuelEmissions(
                        req.fuelType(), req.fuelUnit(), req.fuelQuantity() != null ? req.fuelQuantity() : 0.0);
                details = String.format("Fuel %s (%s), qty=%.3f",
                        n(req.fuelType()), n(req.fuelUnit()), nz(req.fuelQuantity()));
            }
            default -> {
                return ResponseEntity.badRequest().body("Unknown category: " + req.category());
            }
        }

        // Persist an EmissionLog
        EmissionLog log = new EmissionLog();
        // If your entity uses `User user;`:
        log.setUser(user);
        // If it uses a numeric foreign key instead, use: log.setUserId(user.getId());

        log.setCategory(req.category());
        log.setDescription(details);     // adapt if your field name differs
        log.setCo2e(co2e);               // adapt if your field name differs
        log.setCreatedAt(LocalDateTime.now());

        emissionLogRepository.save(log);

        return ResponseEntity.ok(log);
    }

    // --- helpers ---
    private User requireUserFromJwtCookie(HttpServletRequest request) {
        Cookie[] cookies = request.getCookies();
        if (cookies == null) return null;
        Cookie jwtCookie = Arrays.stream(cookies)
                .filter(c -> "jwt".equals(c.getName()))
                .findFirst().orElse(null);
        if (jwtCookie == null) return null;

        String email = jwtUtil.validateToken(jwtCookie.getValue());
        if (email == null) return null;
        return userRepository.findByEmail(email).orElse(null);
    }

    private static String n(String s) { return s == null ? "-" : s; }
    private static double nz(Double d) { return d == null ? 0.0 : d; }
}
